# Lab 6 Starter: Structuring a Web App

## Setup
1. `npm install`
2. Edit `db.js` with your MySQL password (the `university` database from earlier labs).
3. `npm start` (or `node app.js`), then visit http://localhost:3000

## What's done for you
- `app.js` — wires everything together (Express, JSON body parsing, static files, the router).
- `db.js` — the shared connection pool.
- `students.controller.js`'s `list` function — a worked example of the pool → query → JSON pattern.
- `students.routes.js`'s `GET /` route — wired to that worked example.
- `public/index.html` and `public/style.css` — match Lab Sheet 06, Sections 10.3–10.4 exactly.

## What you need to build
Follow Lab Sheet 06:
- **Exercise 1** — confirm the refactor: `GET /students` should already work once you fill in `db.js` and wire things up (mostly done: just confirm it runs).
- **Exercise 2** — in `students.controller.js`: `getOne`, `create` (with validation), `update`, `remove`. Then uncomment the matching routes in `students.routes.js`.
- **Exercise 3** — in `public/main.js`: `load()`, the form's submit handler, and the delete click handler.
- **Exercise 4** (if time) — show validation errors in `#message`, and extend `style.css` further.

Each TODO comment in the stub files points to the relevant section of the lab sheet.
