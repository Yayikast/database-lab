// db.js - one shared connection pool for the whole app
// TODO (Exercise 3):
//   1. Stop connecting as root: use the university_app user from Exercise 2.
//   2. Move the settings into a .env file and read them with process.env
//      (npm install dotenv, then require('dotenv').config() as the very first line).
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'your_root_password',   // <-- a password typed into the code
  database: 'css326_lab10',
  waitForConnections: true,
  connectionLimit: 10,
});

module.exports = pool;
