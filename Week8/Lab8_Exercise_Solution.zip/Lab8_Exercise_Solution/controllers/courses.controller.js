// controllers/courses.controller.js
// Baseline single-table CRUD for courses, carried over from Lab 6.
const pool = require('../config/db');

exports.list = async (req, res) => {
  const [rows] = await pool.query('SELECT id, title, credits FROM courses');
  res.json(rows);
};

exports.getOne = async (req, res) => {
  const [rows] = await pool.execute(
    'SELECT id, title, credits FROM courses WHERE id = ?',
    [req.params.id]
  );
  if (rows.length === 0) return res.status(404).json({ error: 'course not found' });
  res.json(rows[0]);
};

exports.create = async (req, res) => {
  const { title, credits } = req.body;
  if (!title) return res.status(400).json({ error: 'title is required' });
  const [r] = await pool.execute(
    'INSERT INTO courses (title, credits) VALUES (?, ?)',
    [title, credits ?? null]
  );
  res.status(201).json({ id: r.insertId });
};

exports.update = async (req, res) => {
  const { title, credits } = req.body;
  const [r] = await pool.execute(
    'UPDATE courses SET title = ?, credits = ? WHERE id = ?',
    [title, credits ?? null, req.params.id]
  );
  if (r.affectedRows === 0) return res.status(404).json({ error: 'course not found' });
  res.status(204).end();
};

exports.remove = async (req, res) => {
  const [r] = await pool.execute('DELETE FROM courses WHERE id = ?', [req.params.id]);
  if (r.affectedRows === 0) return res.status(404).json({ error: 'course not found' });
  res.status(204).end();
};
