// controllers/students.controller.js
// ANSWER KEY — full solution including Lab 8 Exercises 2-4.
const pool = require('../config/db');

exports.list = async (req, res) => {
  const [rows] = await pool.query('SELECT id, name, major FROM students');
  res.json(rows);
};

// Exercise 3: nested JSON — a student plus a courses[] array, [] if none.
exports.getOne = async (req, res) => {
  const [rows] = await pool.execute(`
    SELECT s.id, s.name, s.major, c.id AS course_id, c.title
    FROM students s
    LEFT JOIN enrolments e ON e.student_id = s.id
    LEFT JOIN courses c ON e.course_id = c.id
    WHERE s.id = ?`, [req.params.id]);

  if (rows.length === 0) return res.status(404).json({ error: 'student not found' });

  const { id, name, major } = rows[0];
  const courses = rows
    .filter(r => r.course_id !== null)
    .map(r => ({ id: r.course_id, title: r.title }));

  res.json({ id, name, major, courses });
};

exports.create = async (req, res) => {
  const { name, major } = req.body;
  if (!name) return res.status(400).json({ error: 'name is required' });
  const [r] = await pool.execute(
    'INSERT INTO students (name, major) VALUES (?, ?)',
    [name, major ?? null]
  );
  res.status(201).json({ id: r.insertId });
};

exports.update = async (req, res) => {
  const { name, major } = req.body;
  const [r] = await pool.execute(
    'UPDATE students SET name = ?, major = ? WHERE id = ?',
    [name, major ?? null, req.params.id]
  );
  if (r.affectedRows === 0) return res.status(404).json({ error: 'student not found' });
  res.status(204).end();
};

exports.remove = async (req, res) => {
  const [r] = await pool.execute('DELETE FROM students WHERE id = ?', [req.params.id]);
  if (r.affectedRows === 0) return res.status(404).json({ error: 'student not found' });
  res.status(204).end();
};

// Exercise 2: read related data.
exports.courses = async (req, res) => {
  const [rows] = await pool.execute(`
    SELECT c.id, c.title, e.grade
    FROM enrolments e
    JOIN courses c ON e.course_id = c.id
    WHERE e.student_id = ?`, [req.params.id]);
  res.json(rows);
};

// Exercise 4: create a relationship.
exports.enrol = async (req, res) => {
  const { course_id, grade } = req.body;
  if (!course_id) return res.status(400).json({ error: 'course_id is required' });
  try {
    const [r] = await pool.execute(
      'INSERT INTO enrolments (student_id, course_id, grade) VALUES (?, ?, ?)',
      [req.params.id, course_id, grade ?? null]);
    res.status(201).json({ id: r.insertId });
  } catch (err) {
    if (err.code === 'ER_NO_REFERENCED_ROW_2')
      return res.status(400).json({ error: 'no such course' });
    if (err.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: 'already enrolled in this course' });
    throw err;
  }
};

// Exercise 4: remove a relationship.
exports.unenrol = async (req, res) => {
  const [r] = await pool.execute(
    'DELETE FROM enrolments WHERE student_id = ? AND course_id = ?',
    [req.params.id, req.params.courseId]);
  if (r.affectedRows === 0)
    return res.status(404).json({ error: 'enrolment not found' });
  res.status(204).end();
};
