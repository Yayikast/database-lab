// public/app.js — ANSWER KEY (Exercise 5)
const studentIdInput = document.getElementById('studentId');
const loadBtn = document.getElementById('loadBtn');
const nameEl = document.getElementById('name');
const majorEl = document.getElementById('major');
const courseListEl = document.getElementById('courseList');
const enrolForm = document.getElementById('enrolForm');
const courseSelect = document.getElementById('courseSelect');

async function show(id) {
  const res = await fetch(`/students/${id}`);
  if (!res.ok) {
    nameEl.textContent = 'Not found';
    majorEl.textContent = '';
    courseListEl.innerHTML = '';
    return;
  }
  const s = await res.json();
  nameEl.textContent = s.name;
  majorEl.textContent = s.major ?? '';
  courseListEl.innerHTML = s.courses.map(c =>
    `<li>${c.title} <button data-course="${c.id}">remove</button></li>`
  ).join('');
}

async function loadCourseOptions() {
  const courses = await (await fetch('/courses')).json();
  courseSelect.innerHTML = courses
    .map(c => `<option value="${c.id}">${c.title}</option>`).join('');
}

loadBtn.addEventListener('click', () => show(studentIdInput.value));

enrolForm.onsubmit = async (e) => {
  e.preventDefault();
  await fetch(`/students/${studentIdInput.value}/courses`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ course_id: courseSelect.value })
  });
  show(studentIdInput.value);
};

courseListEl.addEventListener('click', async (e) => {
  const courseId = e.target.dataset.course;
  if (!courseId) return;
  await fetch(`/students/${studentIdInput.value}/courses/${courseId}`, { method: 'DELETE' });
  show(studentIdInput.value);
});

// Initial load
loadCourseOptions();
show(studentIdInput.value);
