-- 05_exercise1_queries.sql — ANSWER KEY for Exercise 1 (Advanced Reads)
USE css326_university;

-- Part A: each course with its enrolled-student count (JOIN + GROUP BY)
SELECT c.title, COUNT(e.student_id) AS student_count
FROM courses c
LEFT JOIN enrolments e ON e.course_id = c.id
GROUP BY c.id
ORDER BY student_count DESC;

-- Part B: students not enrolled in any course (subquery, NOT IN)
SELECT name FROM students
WHERE id NOT IN (SELECT student_id FROM enrolments);

-- Part C: the view
CREATE VIEW enrolment_details AS
  SELECT s.name AS student, c.title AS course, e.grade
  FROM enrolments e
  JOIN students s ON e.student_id = s.id
  JOIN courses  c ON e.course_id  = c.id;

-- Part D: select from the view for one student, and confirm it matches the join
SELECT * FROM enrolment_details WHERE student = 'Suda Srisawat';
