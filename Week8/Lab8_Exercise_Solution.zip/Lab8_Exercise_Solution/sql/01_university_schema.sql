-- 01_university_schema.sql
-- The university schema used in the lecture slides and lab sheet.
-- enrolments is the junction table you designed in Lab 2.

CREATE DATABASE IF NOT EXISTS css326_university;
USE css326_university;

DROP TABLE IF EXISTS enrolments;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS courses;

CREATE TABLE students (
  id     INT AUTO_INCREMENT PRIMARY KEY,
  name   VARCHAR(100) NOT NULL,
  major  VARCHAR(100)
);

CREATE TABLE courses (
  id      INT AUTO_INCREMENT PRIMARY KEY,
  title   VARCHAR(150) NOT NULL,
  credits INT
);

CREATE TABLE enrolments (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id  INT NOT NULL,
  grade      VARCHAR(2),
  UNIQUE KEY uq_student_course (student_id, course_id),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id)  REFERENCES courses(id)  ON DELETE CASCADE
);
