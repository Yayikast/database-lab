-- 02_university_sample_data.sql
USE css326_university;

INSERT INTO students (name, major) VALUES
  ('Suda Srisawat', 'Computer Engineering'),
  ('Anan Pongsak', 'Information Technology'),
  ('Malee Chaiyaporn', 'Computer Engineering'),
  ('Wichai Boonmee', 'Software Engineering'),
  ('Nok Thanawat', 'Information Technology');

INSERT INTO courses (title, credits) VALUES
  ('Database Programming Laboratory', 1),
  ('Data Structures and Algorithms', 3),
  ('Web Application Development', 3),
  ('Operating Systems', 3),
  ('Computer Networks', 3);

-- Nok Thanawat (student 5) is deliberately left with no enrolments,
-- so Exercise 1's LEFT JOIN / GROUP BY has a course_count = 0 case,
-- and Exercise 3's nested JSON has an empty courses[] case to handle.
INSERT INTO enrolments (student_id, course_id, grade) VALUES
  (1, 1, 'A'),
  (1, 2, 'B+'),
  (1, 3, NULL),
  (2, 1, 'B'),
  (2, 4, 'A-'),
  (3, 1, 'A'),
  (3, 2, 'A'),
  (3, 3, 'B'),
  (4, 5, NULL);
