// routes/students.routes.js — ANSWER KEY
const router = require('express').Router();
const c = require('../controllers/students.controller');

router.get('/', c.list);
router.get('/:id', c.getOne);                       // Exercise 3 (nested JSON)
router.get('/:id/courses', c.courses);               // Exercise 2
router.post('/', c.create);
router.post('/:id/courses', c.enrol);                // Exercise 4
router.put('/:id', c.update);
router.delete('/:id', c.remove);
router.delete('/:id/courses/:courseId', c.unenrol);  // Exercise 4

module.exports = router;
