// config/db.js
// One shared connection pool for the whole app, set up the same way as Lab 6.
// Replace the placeholders below with your own local MySQL credentials.
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'lab9',
  waitForConnections: true,
  connectionLimit: 10,
});

module.exports = pool;
