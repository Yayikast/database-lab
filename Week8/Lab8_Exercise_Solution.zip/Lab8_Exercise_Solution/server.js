// server.js
const express = require('express');
const path = require('path');

const studentsRouter = require('./routes/students.routes');
const coursesRouter = require('./routes/courses.routes');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/students', studentsRouter);
app.use('/courses', coursesRouter);

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = 3000;
app.listen(PORT, () => console.log(`CSS326 Lab 8 starter running on http://localhost:${PORT}`));
