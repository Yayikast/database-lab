# CSS326 Lab 8 — Exercise Answer Key (Complete Solution)

This is the fully worked solution to the five in-class Lab Exercises (lab
sheet section 14 / lecture slides), on the **university** schema
(students/courses/enrolments). It is the same starter project with every
`TODO` filled in — run it the same way:

```
npm install
```
Then open `config/db.js` and fill in your own MySQL host/user/password
(same as Lab 6 — credentials go directly in that file).

Load, in order: `sql/01_university_schema.sql`, `sql/02_university_sample_data.sql`.
`sql/05_exercise1_queries.sql` holds the standalone Exercise 1 queries/view to
run directly in MySQL Workbench.

```
npm start
```

See `Lab8_Exercise_Answer_Key.pdf` for the same solutions with explanations.
