// db.js - one shared connection pool for the whole app
// TODO (Assignment Q6, Q7): connect as bookstore_app, and read these settings
// from a .env file with process.env instead of typing them here.
const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'your_root_password',
  database: 'bookstore_lab10',
  waitForConnections: true,
  connectionLimit: 10,
});

module.exports = pool;
