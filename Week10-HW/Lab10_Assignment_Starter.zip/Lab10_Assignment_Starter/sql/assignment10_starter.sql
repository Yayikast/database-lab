-- CSS326 Lab Assignment 10: Hardening: Performance & Security
-- Name: ____________________   Student ID: __________
-- Database: bookstore_lab10 (run sql/01, 02 and 03 first, as root)
USE bookstore_lab10;

-- Q1. Measure first (1.5 points)
--     EXPLAIN and EXPLAIN ANALYZE a query on books that filters by author.
--     Record type, key, rows and actual time. Screenshot.


-- Q2. Add an index (1.5 points)
--     CREATE INDEX, then repeat Q1. Record what changed. Screenshot.


-- Q3. Joins and foreign keys (1.5 points)
--     SHOW INDEX FROM orders; EXPLAIN a query that joins orders to customers
--     for one customer. Answer the question on the sheet in a comment.


-- Q4. The cost of indexes (1 point): answer in a comment.
--


-- Q5. Injection and the fix (2 points): code changes in controllers/bookController.js.
--     Paste the before and after code here as comments, with your explanation.
--


-- Q6. Least privilege (2 points)
--     CREATE USER, GRANT, SHOW GRANTS, and the failed DROP test.


-- Q7. Protect secrets (1.5 points): .env, .gitignore and db.js.
--     Explain in a comment why .env must not be committed to Git.
--


-- Q8. Short answer (1 point): answer in a comment.
--
